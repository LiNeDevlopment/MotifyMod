window.addEventListener("error", window.handleError = err => {
	const msg = `[Motify Fatal Error]: ${err.message}.\n(file: ${err.filename}, ln: ${err.lineno}, col: ${err.colno})`;

	console.error(msg);
	alert(msg);
});

try {
document.getElementByIdGlobal = function(id) {
	let found = document.getElementById(id);
	if (found) return found;
	for (let i = 0; i < documents.length; i++)
		if (found = documents[i].getElementById(id)) return found;
	return null;
};

document.getElementsByClassNameGlobal = function(cn) {
	const found = Array.from(document.getElementsByClassName(cn));
	for (let i = 0; i < documents.length; i++) {
		const foundHere = documents[i].getElementsByClassName(cn);
		for (let i = 0; i < foundHere.length; i++) found.push(foundHere[i]);
	}
	return found;
};

document.getElementsByTagNameGlobal = function(tn) {
	const found = Array.from(document.getElementsByTagName(tn));
	for (let i = 0; i < documents.length; i++) {
		const foundHere = documents[i].getElementsByTagName(tn);
		for (let i = 0; i < foundHere.length; i++) found.push(foundHere[i]);
	}
	return found;
};

window.globalEventListeners = [];

window.addGlobalEventListener = function(type, event) {
	for (let i = 0; i < documents.length; i++) {
		documents[i].addEventListener(type, event);
		window.globalEventListeners.push({
			type: type,
			event: event
		});
	}
};

window.removeGlobalEventListener = function(type, event) {
	for (let i = 0; i < documents.length; i++) {
		documents[i].removeEventListener(type, event);
		const fi = window.globalEventListeners.findIndex(ev => ev.event == event);
		if (fi != -1) window.globalEventListeners.splice(fi, 1);
	}
};

function css(element) {
	const sheets = [],
		output = {};

	for (let doc of documents)
		for (let sheet of doc.styleSheets) sheets.push(sheet);

	for (let i = 0; i < sheets.length; i++) {
		const rules = sheets[i].cssRules;

		for (let r = 0; r < rules.length; r++) {
			if (element.matches(rules[r].selectorText)) {
				output[rules[r].selectorText] = rules[r].style.cssText.split(";").join(";\n");
			}
		}
	}

	if (element.style.cssText) output.style = element.style.cssText.split(";").join(";\n");

	return output;
}

function searchCSS(search, documents = window.documents) {
	const res = [],
		override = [];
	for (let doc of documents) {
		for (let sheet of doc.styleSheets) {
			for (let i = 0; i < sheet.rules.length; i++) {
				if (sheet.rules[i].cssText.toLowerCase().includes(search.toLowerCase())) {
					res.push({
						document: doc,
						sheet: sheet,
						ruleIdx: i,
						rule: sheet.rules[i],
						css: sheet.rules[i].cssText
					});
				}
			}
		}
	}
	for (let i = 0; i < res.length; i++)
		if (!override.includes(res[i])) override.push(res[i]);
	console.log({
		Results: res,
		Override: Array.from(override.filter(o => o.rule.selectorText), o => o.rule.selectorText.trim()).join(", ")
	});
}

function displayNotificationBubble(content, type, options = {}) {
	const { timeout = 7500 } = options;

	const notif = document.createElement("div"), cont = document.createElement("span"), closeButton = document.createElement("span");
	notif.appendChild(cont);

	notif.className = "momo-notif";
	cont.className = "momo-notif-text";

	cont.textContent = content;

	switch (type) {
		case undefined: case "normal": break;

		case "success": case "succeeded": case "green":
			cont.classList.add("momo-green");
		break;

		case "fail": case "failed": case "failure": case "red": case "error":
			cont.classList.add("momo-red");
		break;

		case "info": case "information": case "blue":
			cont.classList.add("momo-blue");
		break;

		default:
			cont.style.background = type;
		break;
	}

	if (options.onclick) {
		cont.classList.add("momo-has-event");
		cont.addEventListener("click", options.onclick);
	}

	closeButton.className = "material-icons momo-close-btn";
	closeButton.textContent = "close";
	closeButton.addEventListener("click", () => notif.remove());
	cont.appendChild(closeButton);

	window.momoNotificationContainer.appendChild(notif);
	setTimeout(() => notif.remove(), timeout);

	return notif;
};

var styleQueue = {};
window.MotifyAPI = {
	injectCSS: function(id, css) {
		const style = {
			destroy: function() {
				for (let doc of documents)
					if (doc.getElementById(id)) doc.getElementById(id).remove();
				delete styleQueue[id];
			}
		};

		for (let doc of documents)
			if (!doc.getElementById(id)) doc.head.insertAdjacentHTML("beforeEnd", `<style id="${id}">${css}</style>`);
			else doc.getElementById(id).innerHTML = css;

		styleQueue[id] = () => MotifyAPI.injectCSS(id, css);

		return style;
	},

	fileExists: function(filename) {
		const xhr = new XMLHttpRequest();

		xhr.open("HEAD", filename, false);
		try { xhr.send(); }
		catch (err) { return false; }

		return xhr.status != 404;
	},

	readFile: function(filename, callback, options = {}) {
		if (!this.fileExists(filename)) return callback();

		const {	async = true, timeout = 15000 } = options, xhr = new XMLHttpRequest();

		if (async) xhr.timeout = timeout;

		xhr.onreadystatechange = function() {
			if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
				callback(xhr.responseText);
			}
		};
		
		xhr.ontimeout = xhr.onerror = function() {
			callback();
		};

		xhr.open("GET", filename, async);
		xhr.send();
	},

	createLabel: function(label, description = "") {
		const element = document.createElement("label");
		element.className = "col description";
		element.style.position = "relative";
		element.dataset.description = description;
		element.textContent = label;
		return element;
	},

	createSettingsToggle: function(label, state, callback, options = {}) {
		const {	description = "" } = options, element = document.createElement("div");
		element.className = "settings-row";
		element.style.marginTop = "20px";
		if (label) element.appendChild(this.createLabel(label, description));
		element.insertAdjacentHTML("beforeEnd",
			`<div class="col action" style="float:right">
				<div role="checkbox" class="${state ? "enabled " : ""}slider">
					<div></div>
				</div>
			</div>`);
		element.lastElementChild.firstElementChild.addEventListener("click", function(e) {
			callback(!e.currentTarget.classList.contains("enabled"));
			if (e.currentTarget.classList.contains("enabled")) e.currentTarget.classList.remove("enabled");
			else e.currentTarget.classList.add("enabled");
		});
		return element;
	},

	createSettingsTextField: function(label, value, callback, options = {}) {
		const { type = "string", description = "" } = options, element = document.createElement("div");
		element.className = "settings-row";
		element.style.marginTop = "20px";
		if (label) element.appendChild(this.createLabel(label, description));
		element.insertAdjacentHTML("beforeEnd", `<input class="momo-addon-textfield" value="${value}"/>`);
		let last = value;
		element.lastElementChild.addEventListener("focusout", function(e) {
			switch (type) {
				case "number": case "float": case "floating point":
					if (!e.target.value) {
						callback(e.target.value = last = 0);
						break;
					}
					if (isNaN(e.target.value)) {
						displayNotificationBubble("Value must be a number!", "error");
						e.target.value = last;
						break;
					}
					callback(last = parseFloat(e.target.value));
				break;

				case "whole number": case "int": case "integer":
					if (!e.target.value) {
						callback(e.target.value = last = 0);
						break;
					}
					if (isNaN(e.target.value)) {
						displayNotificationBubble("Value must be a number!", "error");
						e.target.value = last;
						break;
					}
					callback(last = e.target.value = parseInt(e.target.value));
				break;

				default: callback(last = e.target.value);
			}
		});
		return element;
	},

	createSettingsRadioGroup: function(label, value, choices, callback, options = {}) {
		const element = document.createElement("div");
		element.className = "momo-radio-group";
		if (label) element.appendChild(this.createLabel(label, options.description));

		const list = document.createElement("div");

		const update = () => {
			for (let choice of element.getElementsByClassName("momo-radio-button")) {
				if (choice.dataset.key == value) choice.classList.add("esrb-selected");
				else choice.classList.remove("esrb-selected");
			}
		};

		const createRadioButton = choice => {
			const c = document.createElement("div");
			c.className = "momo-radio-button";
			c.dataset.key = choice;
			if (value == choice) c.classList.add("esrb-selected");

			const t = document.createElement("span");
			t.className = "esrb-box";

			c.appendChild(t);
			c.appendChild(this.createLabel(choices[choice].label, choices[choice].description));

			c.addEventListener("click", () => {
				callback(value = choice);
				update();
			});

			return c;
		};

		for (let choice in choices) element.appendChild(createRadioButton(choice));

		return element;
	}

};

window.motifySettings = {
	developerMode: false,
	logBridgeRequests: false,
	logLocalBridgeRequests: false,
	logEventListeners: false,
	checkForAddonUpdates: true
};

window.saveSettings = function() {
	window.localStorage.setItem("motifySettings", JSON.stringify(window.motifySettings));
};

try {
	let saved = window.localStorage.getItem("motifySettings");
	if (saved) {
		saved = JSON.parse(saved);
		for (let setting in saved) window.motifySettings[setting] = saved[setting];
	}
} finally {
	window.saveSettings();
}

window.observer = new MutationObserver(function(mutations) {
	for (let m = 0; m < mutations.length; m++) {
		const mutation = mutations[m];
		
		for (let i = 0; i < mutation.addedNodes.length; i++) {
			const added = mutation.addedNodes[i];
			if (typeof window.addonLoader != "undefined") addonLoader.callPluginEvent("onNodeAdded", added);
			if (added.localName == "section" && added.children[0] && added.children[0].children[0].innerText == "Language") {
				onSettingsLoaded(document.getElementByIdGlobal("settings"));
			}
		}
		
		for (let i = 0; i < mutation.removedNodes.length; i++) {
			const removed = mutation.removedNodes[i];
			if (typeof window.addonLoader != "undefined") addonLoader.callPluginEvent("onNodeRemoved", removed);
		}
	}
});

function sortObject(obj, comp, reverse) {
	const sorted = {}, array = [];

	for (let key in obj)
		if (obj.hasOwnProperty(key))
			array.push(key);
	
	array.sort(comp);
	if (reverse) array.reverse();

	for (let i = 0; i < array.length; i++) sorted[array[i]] = obj[array[i]];

	return sorted;
}

let shouldLoadPluginSettings = false;
let shouldLoadThemeSettings = false;
let shouldLoadAddonList = false;

function onSettingsLoaded(menu) {
	try {
		if (document.getElementByIdGlobal("momo-plugin-settings")) document.getElementByIdGlobal("momo-plugin-settings").remove();
		if (document.getElementByIdGlobal("momo-theme-settings")) document.getElementByIdGlobal("momo-theme-settings").remove();
		if (document.getElementByIdGlobal("momo-verified-addons")) document.getElementByIdGlobal("momo-verified-addons").remove();

		const getAddonItemHTML = function(item, enabled, type) {
			return `<div class="section-divider momo-addon-item${!enabled ? " is-disabled" : ""}">
				<h2 data-creator="${item.creator || "Unknown User"}">${item.name}</h2>
				${typeof item.settingFields != "undefined" && Object.keys(item.settingFields).length || type == "theme" && Object.keys(addonLoader.getThemeVariables(item.data)).length ? `<div class="material-icons momo-addon-settings-button">settings</div>` : ""}
				<div class="col action" style="float:right">
					<div role="checkbox" class="${enabled ? "enabled " : ""}slider">
						<div></div>
					</div>
				</div>
				<label class="col description" style="font-weight:lighter;margin-top:5px;width:100%">${item.description || ""}</label>
				<div class="momo-addon-settings">

				</div>
			</div>`;
		};

		const addAddonItem = function(settings, item, type) {
			const html = getAddonItemHTML(item, type == "plugin" ? addonLoader.enabledPlugins[item.keyName] : addonLoader.enabledThemes[item.keyName], type);

			settings.insertAdjacentHTML("beforeEnd", html);

			const element = settings.lastChild,
				settingsButton = element.getElementsByClassName("momo-addon-settings-button")[0],
				toggleButton = element.getElementsByClassName("col action")[0];

			let animating = false;

			const openAddonSettings = pop => {
				if (animating) return;
				animating = true;
				element.classList.add("settings-opened", "settings-opened-" + item.keyName);
				closedHeight = element.offsetHeight;
				pop();
				const openedHeight = element.offsetHeight;
				element.insertAdjacentHTML("beforeBegin", `
					<style id="momo-settings-style-opening-${item.keyName}">
						.momo-addon-item.settings-opened-${item.keyName} {
							height: ${closedHeight}px;
							animation: settings-opening-${item.keyName} 0.5s forwards;
						}
						@keyframes settings-opening-${item.keyName} {
							0% { height: ${closedHeight}px; }
							100% { height: ${openedHeight}px; }
						}
					</style>
				`);
				setTimeout(() => {
					animating = false;
					document.getElementByIdGlobal("momo-settings-style-opening-" + item.keyName).remove();
				}, 500);
			};

			const closeAddonSettings = () => {
				if (animating) return;
				animating = true;
				const openedHeight = element.offsetHeight;
				element.insertAdjacentHTML("beforeBegin", `
					<style id="momo-settings-style-closing-${item.keyName}">
						.momo-addon-item.settings-opened-${item.keyName} {
							height: ${openedHeight}px;
							animation: settings-closing-${item.keyName} 0.5s forwards;
						}
						@keyframes settings-closing-${item.keyName} {
							0% { height: ${openedHeight}px; }
							100% { height: ${closedHeight}px; }
						}
					</style>
				`);
				element.classList.remove("settings-opened");
				setTimeout(() => {
					animating = false;
					document.getElementByIdGlobal("momo-settings-style-closing-" + item.keyName).remove();
					element.getElementsByClassName("momo-addon-settings")[0].innerHTML = "";
					element.classList.remove("settings-opened-" + item.keyName);
				}, 500);
			};

			if (settingsButton) {
				if (type == "plugin") settingsButton.addEventListener("click", function() {
					if (!element.classList.contains("settings-opened")) {
						openAddonSettings(() => {
							for (let field in item.settingFields) {
								try {

									let repop, array, insertDeleteButton;

									if (item.settingFields[field].array || item.settingFields[field].list) {

										const list = document.createElement("div");
										list.className = "momo-addon-setting-array";
										list.innerHTML = `<label class="col description" data-description="${item.settingFields[field].description || ""}">${item.settingFields[field].label}</label><div class="momo-addon-settings-array-items" style="margin:5px"></div>`;

										array = list.getElementsByClassName("momo-addon-settings-array-items")[0];

										if (item.settingFields[field].array) {

											const addButton = document.createElement("button"),
												clearButton = document.createElement("button");
											addButton.className = clearButton.className = "button button-with-stroke";
											addButton.style = clearButton.style = "margin: 10px";

											addButton.textContent = "Add";
											addButton.addEventListener("click", () => {
												item.settings[field].push("");
												array.innerHTML = "";
												addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field + ".add");
												repop();
												addonLoader.save();
											});

											clearButton.textContent = "Clear";
											clearButton.addEventListener("click", () => {
												addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field + ".clear", item.settings[field], item.settings[field] = []);
												array.innerHTML = "";
												repop();
												addonLoader.save();
											});

											insertDeleteButton = i => {
												array.lastElementChild.insertAdjacentHTML("afterBegin", `<span class="material-icons" style="float:right;cursor:pointer">close</span>`);
												array.lastElementChild.firstElementChild.addEventListener("click", () => {
													addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field + ".remove", item.settings[field][i]);
													item.settings[field].splice(i, 1);
													array.innerHTML = "";
													repop();
													addonLoader.save();
												});
											};

											list.appendChild(addButton);
											list.appendChild(clearButton);

										}

										element.lastElementChild.appendChild(list);

									}
									switch (item.settingFields[field].type ? item.settingFields[field].type : null) {
										case null: case "bool": case "boolean":
											if (array) {
												(repop = () => {
													for (let i in item.settings[field]) {
														array.appendChild(MotifyAPI.createSettingsToggle(i, item.settings[field][i], () => {
															addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field + "[" + i + "]", item.settings[field][i], item.settings[field][i] = !item.settings[field][i]);
															addonLoader.save();
														}));
														if (item.settingFields[field].array) insertDeleteButton(i);
													}
												})();
											} else {
												element.lastElementChild.appendChild(MotifyAPI.createSettingsToggle(item.settingFields[field].label, item.settings[field], () => {
													addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field, item.settings[field], item.settings[field] = !item.settings[field]);
													addonLoader.save();
												}, { description: item.settingFields[field].description }));
											}
										break;

										case "radio": case "radio group":
											element.lastElementChild.appendChild(MotifyAPI.createSettingsRadioGroup(item.settingFields[field].label, item.settings[field], item.settingFields[field].choices, nv => {
												addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field, item.settings[field], item.settings[field] = nv);
												addonLoader.save();
											}, { description: item.settingFields[field].description }));
										break;

										case "custom":
											if (array) {
												(repop = () => {
													for (let i in item.settings[field]) {
														if (typeof item.settingFields[field].element == "function") {
															array.appendChild(item.settingFields[field].element(item, value => {
																addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field + "[" + i + "]", item.settings[field] = value);
																addonLoader.save();
															}));
															if (item.settingFields[field].array) insertDeleteButton(i);
														} else if (item.settingFields[field].html) {
															element.lastElementChild.insertAdjacentHTML("beforeEnd", item.settingFields[field].html);
															if (item.settingFields[field].array) insertDeleteButton(i);
														}
													}
												})();
											} else {
												if (typeof item.settingFields[field].element == "function") {
													element.lastElementChild.appendChild(item.settingFields[field].element(item, value => {
														addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field, item.settings[field], item.settings[field] = value);
														addonLoader.save();
													}));
												}
												if (item.settingFields[field].html) element.lastElementChild.insertAdjacentHTML("beforeEnd", item.settingFields[field].html);
											}
										break;

										default:
											if (array) {
												(repop = () => {
													for (let i in item.settings[field]) {
														array.appendChild(MotifyAPI.createSettingsTextField(i, item.settings[field][i], e => {
															addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field + "[" + i + "]", item.settings[field][i], item.settings[field][i] = e);
															addonLoader.save();
														}, {
															type: item.settingFields[field].type
														}));
														if (item.settingFields[field].array) insertDeleteButton(i);
													}
												})();
											} else {
												element.lastElementChild.appendChild(MotifyAPI.createSettingsTextField(item.settingFields[field].label, item.settings[field], e => {
													addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field, item.settings[field], item.settings[field] = e);
													addonLoader.save();
												}, {
													type: item.settingFields[field].type,
													description: item.settingFields[field].description
												}));
											}
									}
								} catch (err) {
									console.error({
										"Error loading setting field": err
									});
								}
							}
						});
					} else closeAddonSettings();
				});
				else settingsButton.addEventListener("click", function() {
					if (!element.classList.contains("settings-opened")) {
						openAddonSettings(() => {
							const variables = addonLoader.getThemeVariables(item.data);
							for (let variable in variables) {
								try {
									element.lastElementChild.appendChild(MotifyAPI.createSettingsTextField(variable, window.motifyThemeSettings[variable] || "", set => {
										window.motifyThemeSettings[variable] = set;
										addonLoader.updateThemeSettings();
										addonLoader.save();
									}, {
										description: "Default: " + variables[variable]
									}));
								} catch (err) {
									console.error({
										"Error loading setting field": err
									});
								}
							}
						});
					} else closeAddonSettings();
				});
			}

			toggleButton.addEventListener("click", function() {
				if (type == "plugin") {
					if (addonLoader.enabledPlugins[item.keyName]) {
						if (typeof item.end == "function") item.end();
						addonLoader.enabledPlugins[item.keyName] = false;
					} else {
						if (typeof item.init == "function") item.init();
						addonLoader.enabledPlugins[item.keyName] = true;
					}
				} else {
					if (addonLoader.enabledThemes[item.keyName]) {
						if (item.instance) item.instance.destroy();
						addonLoader.enabledThemes[item.keyName] = false;
					} else {
						item.instance = MotifyAPI.injectCSS(item.keyName, item.data);
						addonLoader.enabledThemes[item.keyName] = true;
					}
				}
				if (element.classList.contains("is-disabled")) element.classList.remove("is-disabled");
				else element.classList.add("is-disabled");
				if (toggleButton.firstElementChild.classList.contains("enabled")) toggleButton.firstElementChild.classList.remove("enabled");
				else toggleButton.firstElementChild.classList.add("enabled");
				addonLoader.save();
			});
		};

		if (shouldLoadPluginSettings) {
			for (let sect of menu.children) sect.style.display = "none";

			const settings = document.createElement("section");
			settings.id = "momo-plugin-settings";

			const plugins = sortObject(window.motifyPlugins, (a, b) => {
				const x = a.toLowerCase(), y = b.toLowerCase()
				if (x > y) return 1;
				else if (x < y) return -1;
				else return 0;
			});

			for (let name in plugins) addAddonItem(settings, window.motifyPlugins[name], "plugin");

			menu.appendChild(settings);

			document.getElementsByClassNameGlobal("glue-page-header__title-text")[0].textContent = "Motify Plugins";

			shouldLoadPluginSettings = false;
		} else if (shouldLoadThemeSettings) {
			for (let sect of menu.children) sect.style.display = "none";

			const items = document.createElement("section");
			items.id = "momo-theme-settings";

			const themes = sortObject(window.motifyThemes, (a, b) => {
				const x = a.toLowerCase(), y = b.toLowerCase()
				if (x > y) return 1;
				else if (x < y) return -1;
				else return 0;
			});

			for (let name in themes) addAddonItem(items, window.motifyThemes[name], "theme");

			menu.appendChild(items);

			document.getElementsByClassNameGlobal("glue-page-header__title-text")[0].textContent = "Motify Themes";

			shouldLoadThemeSettings = false;
		} else if (shouldLoadAddonList) {
			for (let sect of menu.children) sect.style.display = "none";

			const items = document.createElement("section");
			items.id = "momo-verified-addons";

			const loadingText = MotifyAPI.createLabel("Fetching verified addons...");
			items.appendChild(loadingText);

			fetch("https://raw.githubusercontent.com/Metalloriff/MotifyMod/master/verifiedaddons.json", { cache: "no-cache" }).then(response => response.json()).then(data => {
				loadingText.remove();

				items.insertAdjacentHTML("beforeEnd", `
					<section class="verified-plugins"><div class="section-divider"><h4>Plugins</h4></div></section>
					<section class="verified-themes"><div class="section-divider"><h4>Themes</h4></div></section>
				`);

				const sort = (a, b) => {
					const x = a.toLowerCase(), y = b.toLowerCase()
					if (x > y) return 1;
					else if (x < y) return -1;
					else return 0;
				};

				const plugins = sortObject(data.plugins, sort), themes = sortObject(data.themes, sort);

				const pluginItems = items.getElementsByClassName("verified-plugins")[0], themeItems = items.getElementsByClassName("verified-themes")[0];

				const addonItem = addon => {
					return `<div class="section-divider momo-addon-item">
						<h2 data-creator="${addon.creator}">${addon.name}</h2>
						<button class="button button-green" style="float:right;margin-right:10px">Get</button>
						<label class="col description" style="font-weight:lighter;margin-top:5px;width:100%">${addon.description || ""}</label>
					</div>`;
				};

				for (let url in data.plugins) {
					const plugin = data.plugins[url];
					
					pluginItems.insertAdjacentHTML("beforeEnd", addonItem(plugin));

					pluginItems.lastElementChild.getElementsByClassName("button")[0].addEventListener("click", () => window.open(url));
				}

				for (let url in data.themes) {
					const theme = data.themes[url];
					
					themeItems.insertAdjacentHTML("beforeEnd", addonItem(theme));

					themeItems.lastElementChild.getElementsByClassName("button")[0].addEventListener("click", () => window.open(url));
				}
			}).catch(err => {
				loadingText.textContent = "Error fetching verified addons";
				console.error({ "Error fetching verified addons": err });
			});

			menu.appendChild(items);

			document.getElementsByClassNameGlobal("glue-page-header__title-text")[0].textContent = "Verified Motify Addons";

			shouldLoadAddonList = false;
		} else {
			for (let sect of menu.children) sect.style.display = "";
			if (!document.getElementByIdGlobal("momo-settings")) {
				const settings = document.createElement("section");
				settings.id = "momo-settings";
				settings.innerHTML = `
					<div class="section-divider">
						<h2 data-description="by Metalloriff">Motify</h2>
					</div>
				`;

				settings.appendChild(MotifyAPI.createSettingsToggle("Developer mode", motifySettings.developerMode, bool => {
					motifySettings.developerMode = bool;
					setDevMode(bool);
					saveSettings();
				}, { description: "Also allows access to Chrome dev tools (Ctrl + Shift + I) (requires restart)" }));

				settings.appendChild(MotifyAPI.createSettingsToggle("Check for addon updates on startup", motifySettings.checkForAddonUpdates, bool => {
					motifySettings.checkForAddonUpdates = bool;
					saveSettings();
				}));

				settings.appendChild(MotifyAPI.createSettingsToggle("Log unblocked bridge requests to console", motifySettings.logBridgeRequests, bool => {
					motifySettings.logBridgeRequests = bool;
					saveSettings();
				}));

				settings.appendChild(MotifyAPI.createSettingsToggle("Log local bridge requests to console", motifySettings.logLocalBridgeRequests, bool => {
					motifySettings.logLocalBridgeRequests = bool;
					saveSettings();
				}));

				settings.appendChild(MotifyAPI.createSettingsToggle("Log added event listeners", motifySettings.logEventListeners, bool => {
					motifySettings.logEventListeners = bool;
					saveSettings();
				}));

				settings.appendChild(MotifyAPI.createLabel("Motify Discord Server"));

				settings.insertAdjacentHTML("beforeEnd", `<iframe src="https://discordapp.com/widget?id=477971161817284608&theme=dark" width="350" height="500" allowtransparency="true" frameborder="0" style="display:block"></iframe>`);

				document.getElementByIdGlobal("basic-settings").insertBefore(settings, document.getElementByIdGlobal("language"));
			}
			document.getElementsByClassNameGlobal("glue-page-header__title-text")[0].textContent = "Settings";
		}

		addonLoader.callPluginEvent("onSettingsMenu", menu);
	} catch (err) {
		console.error({
			"onSettingsLoaded Error": err
		});
	}
}

document.addEventListener("click", function(e) {
	if (e.target.id == "profile-menu-toggle" && document.getElementsByClassName("GlueMenu__root-items").length) {
		const settingsButton = document.querySelector('[data-menu-item="settings"]');
		if (!settingsButton) return;

		settingsButton.outerHTML = `
			<button id="momo-plugins-button" class="GlueMenuItem" role="menuitem" data-submenu="false">Motify Plugins</button>
			<button id="momo-themes-button" class="GlueMenuItem" role="menuitem" data-submenu="false">Motify Themes</button>
			<button id="momo-verified-addons-button" class="GlueMenuItem" role="menuitem" data-submenu="false">Verified Addons</button>
			${settingsButton.outerHTML}
		`;

		const glueMenuItems = document.getElementsByClassName("GlueMenuItem"),
			pluginsButton = document.getElementById("momo-plugins-button"),
			themesButton = document.getElementById("momo-themes-button"),
			addonListButton = document.getElementById("momo-verified-addons-button");
		
		for (let i = 0; i < glueMenuItems.length; i++) {
			glueMenuItems[i].addEventListener("mouseover", () => {
				for (let hovered of document.getElementsByClassName("GlueMenuItem")) hovered.classList.remove("selected");
				glueMenuItems[i].classList.add("selected");
			});

			glueMenuItems[i].addEventListener("mouseleave", () => {
				glueMenuItems[i].classList.remove("selected");
			});

			if (glueMenuItems[i].dataset.menuItem == "settings") {
				glueMenuItems[i].addEventListener("click", function() {
					if (document.getElementByIdGlobal("settings")) onSettingsLoaded(document.getElementByIdGlobal("settings"));
				});
			}
		}

		pluginsButton.addEventListener("click", function() {
			shouldLoadPluginSettings = true;
			if (document.getElementByIdGlobal("settings")) onSettingsLoaded(document.getElementByIdGlobal("settings"));
			const EVENT = SpotifyInternals.getModuleById(10);
			SpotifyInternals.getModuleById(9).dispatchEvent(new EVENT(EVENT.TYPES.NAVIGATION_OPEN_URI, "spotify:app:settings"));
			document.getElementById("profile-menu-toggle").click();
		});

		themesButton.addEventListener("click", function() {
			shouldLoadThemeSettings = true;
			if (document.getElementByIdGlobal("settings")) onSettingsLoaded(document.getElementByIdGlobal("settings"));
			const EVENT = SpotifyInternals.getModuleById(10);
			SpotifyInternals.getModuleById(9).dispatchEvent(new EVENT(EVENT.TYPES.NAVIGATION_OPEN_URI, "spotify:app:settings"));
			document.getElementById("profile-menu-toggle").click();
		});

		addonListButton.addEventListener("click", function() {
			shouldLoadAddonList = true;
			if (document.getElementByIdGlobal("settings")) onSettingsLoaded(document.getElementByIdGlobal("settings"));
			const EVENT = SpotifyInternals.getModuleById(10);
			SpotifyInternals.getModuleById(9).dispatchEvent(new EVENT(EVENT.TYPES.NAVIGATION_OPEN_URI, "spotify:app:settings"));
			document.getElementById("profile-menu-toggle").click();
		});
	}
});

var documents = [document],
	windows = [window];

(window.patchWindow = async function(w) {

	(function() {
		const unpatched = {
			addEventListener: w.HTMLElement.prototype.addEventListener,
			removeEventListener: w.HTMLElement.prototype.removeEventListener
		};

		const eventListeners = {};

		w.Element.prototype.addEventListener = function() {
			unpatched.addEventListener.apply(this, arguments);

			if (!eventListeners[this]) eventListeners[this] = {};
			if (!eventListeners[this][arguments[0]]) eventListeners[this][arguments[0]] = {};
			eventListeners[this][arguments[0]] = [arguments[1]];
			this.eventListeners = eventListeners[this];

			const logObj = {};

			logObj[(this.id || this.className || this.nodeName) + "." + arguments[0]] = {
				type: arguments[0],
				event: arguments[1],
				keys: Object.keys(this),
				convertedKeys: Array.from(Object.keys(this), key => this[key]),
				element: this
			};

			if (motifySettings.logEventListeners) console.log(logObj);
		};

		w.Element.prototype.removeEventListener = function() {
			unpatched.removeEventListener.apply(this, arguments);

			try {
				delete eventListeners[this][arguments[0]];
			} finally {}
			this.eventListeners = eventListeners[this];
		};

	})();

	const timeout = performance.now();
	while (typeof w.__spotify == "undefined" && performance.now() - timeout < 5000) await new Promise(p => setTimeout(p, 0));
	if (performance.now() - timeout > 5000) return;

	w.onerror = function() {
		const errorMessage = {};
		errorMessage[w.name + ".onerror"] = arguments;
		console.log(errorMessage);
	};

	const unpatchedBridgeRequest = w._getSpotifyModule("bridge").executeRequest;

	w._getSpotifyModule("bridge").executeRequest = function() {
		const obj = {},
			data = JSON.parse(arguments[0]),
			uri = data.args && data.args[1] && data.args[1].uri ? data.args[1].uri : null;

		const unpatchedSuccess = arguments[1].onSuccess;
		if (unpatchedSuccess) arguments[1].onSuccess = e => {
			try {
				const parsed = JSON.parse(e);
				if (uri) {
					const o = {};
					o["Success for " + uri] = parsed;
					if (motifySettings.logBridgeRequests) console.log(o);
				}
			} catch (err) {
				console.error({
					error: err
				});
			}
			unpatchedSuccess(e);
		};

		if (!uri && !motifySettings.logLocalBridgeRequests) return unpatchedBridgeRequest.apply(w, arguments);

		obj[(uri ? "Bridge" : "Local Bridge") + " Request (" + (uri || data.name || "unknown") + ")"] = {
			data: data,
			events: arguments[1]
		};

		if (motifySettings.logBridgeRequests) console.log(obj);

		return unpatchedBridgeRequest.apply(w, arguments);
	};

	console.log({ "Patched": w.location.href });

})(window);

window.ReactData = {

	get: function(element) {
		if (!(element instanceof Element)) return null;
		return element[Object.keys(element).find(key => key.startsWith("__reactInternalInstance"))];
	},

	getEvents: function(element) {
		if (!(element instanceof Element)) return null;
		return element[Object.keys(element).find(key => key.startsWith("__reactEventHandlers"))];
	},

	getOwner: function(element) {

		if (!(element instanceof Element)) return null;

		const reactData = this.get(element);

		if (reactData == undefined) return null;

		for (let c = reactData.return; !_.isNil(c); c = c.return) {
			if (_.isNil(c)) continue;
			const owner = c.stateNode;
			if (!_.isNil(owner) && !(owner instanceof HTMLElement)) return owner;
		}

	},

	getProps: function(element) {

		if (!(element instanceof Element)) return null;

		const owner = this.getOwner(element);

		return owner ? owner.props : null;

	},

	getProp: function(element, propKey) {

		if (!(element instanceof Element)) return null;

		const owner = this.getOwner(element);

		if (!owner || !owner.props) return null;

		const split = propKey.split("."),
			obj = owner.props;

		for (let i = 0; i < split.length; i++) {
			obj = obj[split[i]];
			if (!obj) return null;
		}

		return obj;

	},

};

window.onAppLoaded = function(appWindow, appDocument) {
	console.log({ "App loaded": appWindow.name = appWindow.location.href.match(/:\/\/[^\.]+\./)[0].match(/[a-z]/g).join("") });
	windows.push(appWindow);
	appDocument.body.id = "root";
	appDocument.body.classList.add("momo-doc-" + appWindow.name);
	documents.push(appDocument);
	observer.observe(appDocument, { childList: true, subtree: true });
	patchWindow(appWindow);
	for (let id in styleQueue) styleQueue[id]();
	for (let i = 0; i < window.globalEventListeners.length; i++) appDocument.addEventListener(window.globalEventListeners[i].type, window.globalEventListeners[i].event);
	if (typeof window.addonLoader != "undefined") addonLoader.callPluginEvent("onAppLoaded", appWindow, appDocument);
};

observer.observe(document, { childList: true, subtree: true });

(async function() {
	while (document.body == null) await new Promise(p => setTimeout(p, 0));
	window.name = "zlink";
	document.body.insertAdjacentHTML("afterBegin", `<div id="app-background" style="z-index:-10000;position:fixed;top:0;left:0;right:0;bottom:0"></div>`);
	document.body.insertAdjacentHTML("beforeEnd", `<div class="momo-notifs"></div>`);
	window.momoNotificationContainer = document.getElementsByClassName("momo-notifs")[0];
	document.body.id = "zlink-root";
	document.body.classList.add("momo-doc-zlink");
})();

MotifyAPI.readFile("motify/main.css", css => MotifyAPI.injectCSS("momoMain", css));
MotifyAPI.readFile("https://fonts.googleapis.com/icon?family=Material+Icons", css => MotifyAPI.injectCSS("materialIcons", css));

MotifyAPI.readFile("https://raw.githubusercontent.com/Metalloriff/MotifyMod/master/Core/metadata", metadata => {
	const lines = metadata.split("\n");
	for (let i = 0; i < lines.length; i++) {
		if (!lines[i].includes(":")) continue;

		const key = lines[i].split(":")[0].trim(),
			value = lines[i].split(":")[1].trim();
		
		if (key == "version") {
			if (localStorage.getItem("lastCheckedVersion") && localStorage.getItem("lastCheckedVersion") != value) {
				alert("There is a new version of Motify available! Run the installer to update.");
				localStorage.setItem("lastCheckedVersion", value);
			}
		}
	}
});

addGlobalEventListener("keydown", function(e) {
	if (e.key == "F8") {
		debugger;
	}
});

window.initModuleGetter = function(t, n) {
	const cachedModules = {};

	for (let i in t)
		if (t[i].exports) t[i].exports.moduleId = i;

	window.SpotifyInternals = {
		modules: t,
		getModuleById: n,
		findModule: function(filter, options = {}) {
			const {
				returnModule = true, suppressWarning = false
			} = options;
			for (let i in t) {
				if (t.hasOwnProperty(i)) {
					const m = t[i].exports;
					if (m && m.__esModule && m.default && filter(m.default)) return returnModule ? m.default : t[i];
					if (m && filter(m)) return m;
				}
			}
			if (!suppressWarning) console.warn("No module found by this filter!", filter);
			return null;
		},
		findModules: function(filter, options = {}) {
			const {
				returnModule = true, suppressWarning = false
			} = options, found = [];
			for (let i in t) {
				if (t.hasOwnProperty(i)) {
					const m = t[i].exports;
					if (m && m.__esModule && m.default && filter(m.default)) found.push(returnModule ? m.default : t[i]);
					else if (m && filter(m)) found.push(m);
				}
			}
			return found;
		},
		getModuleByProps: function(props) {
			const cacheKey = props.join(",");
			if (!cachedModules[cacheKey]) cachedModules[cacheKey] = this.findModule(module => props.every(prop => module[prop]));
			return cachedModules[cacheKey];
		},
		getModuleByProp: function(prop) {
			if (!cachedModules[prop]) cachedModules[prop] = this.findModule(module => module[prop]);
			return cachedModules[prop];
		}
	};

	window.searchModules = function(search) { //Use this for debugging, so you can find what props you're looking for. Do not use this for getting modules in plugins.
		const found = {};
		SpotifyInternals.findModule(module => {
			for (let key in module)
				if (!found[key] && key.toLowerCase().includes(search.toLowerCase())) found[key] = module;
			for (let key in module.__proto__)
				if (!found[key] && key.toLowerCase().includes(search.toLowerCase())) found[key] = module;
		}, {
			suppressWarning: true
		});
		console.log({
			"Found Modules": found
		});
	};
};

(window.addonLoader = function() {

	window.motifyPlugins = {};
	window.motifyThemes = {};

	window.motifyPluginSettings = JSON.parse(localStorage.getItem("pluginSettings")) || {};
	window.motifyThemeSettings = JSON.parse(localStorage.getItem("themeSettings")) || {};

	addonLoader.enabledPlugins = JSON.parse(localStorage.getItem("enabledPlugins")) || {};
	addonLoader.enabledThemes = JSON.parse(localStorage.getItem("enabledThemes")) || {};

	addonLoader.updateChecked = [];

	addonLoader.loadPlugin = async function(name, data) {
		try {
			const plugin = eval(`(function(){${data}})();`),
				key = name.split(".")[0];
			if (typeof plugin.name == "undefined") plugin.name = key;
			plugin.keyName = key;
			plugin.filename = name;
			window.motifyPlugins[key] = plugin;
			if (addonLoader.enabledPlugins[key] == undefined) {
				addonLoader.enabledPlugins[key] = true;
				addonLoader.save();
			}
			if (plugin.defaultSettings != undefined) {
				plugin.settings = plugin.defaultSettings;
				if (window.motifyPluginSettings[key])
					for (let saved in window.motifyPluginSettings[key]) plugin.settings[saved] = window.motifyPluginSettings[key][saved];
				window.motifyPluginSettings[key] = plugin.settings;
				addonLoader.save();
			}
			while (typeof window.SpotifyInternals == "undefined") await new Promise(p => setTimeout(p, 0));
			if (addonLoader.enabledPlugins[key])
				if (typeof plugin.init == "function") plugin.init();
			console.log(name + " loaded.");
		} catch (err) {
			console.error({
				"Error Loading Plugin": {
					Plugin: name,
					Error: err
				}
			});
		}
	};

	addonLoader.loadTheme = async function(name, data) {
		try {
			const key = name.split(".")[0];
			window.motifyThemes[key] = {
				name: key,
				keyName: key,
				filename: name,
				data: data
			};
			if (data.toLowerCase().includes("themeinfo")) {
				try {
					const td = JSON.parse("{" + data.split("{").join("}").split("}")[1].trim() + "}");
					for (let k in td) {
						if (k != "filename" && k != "settings" && k != "data") {
							window.motifyThemes[key][k] = td[k];
						}
					}
				} catch (err) {
					console.errror({
						"Error parsing theme info": err
					});
				}
			}
			const variables = addonLoader.getThemeVariables(data);
			for (let variable in variables)
				if (window.motifyThemeSettings[variable] == undefined) window.motifyThemeSettings[variable] = variables[variable].split(";")[0];
			if (addonLoader.enabledThemes[key] == undefined) {
				addonLoader.enabledThemes[key] = true;
				addonLoader.save();
			}
			if (addonLoader.enabledThemes[key]) window.motifyThemes[key].instance = MotifyAPI.injectCSS(key, data);
			addonLoader.updateThemeSettings();
			console.log(name + " loaded.");
		} catch (err) {
			console.error({
				"Error Loading Theme": {
					Theme: name,
					Error: err
				}
			});
			alert("Error Loading " + name + ":\n" + err);
		}
	};

	(addonLoader.refreshAddons = async function() {
		MotifyAPI.readFile("motify/addons.json", async function(raw) {
			const data = JSON.parse(raw);

			for (let i = 0; i < data.plugins.length; i++) {
				if (window.motifyPlugins[data.plugins[i].split(".")[0]]) continue;

				MotifyAPI.readFile("motify/plugins/" + data.plugins[i], function(pluginData) {
					if (pluginData) addonLoader.loadPlugin(data.plugins[i], pluginData);
				}, { async: false });
			}

			for (let i = 0; i < data.themes.length; i++) {
				if (window.motifyThemes[data.themes[i].split(".")[0]]) continue;

				MotifyAPI.readFile("motify/themes/" + data.themes[i], function(themeData) {
					if (themeData) addonLoader.loadTheme(data.themes[i], themeData);
				}, { async: false });
			}
		});
	})();
	setInterval(addonLoader.refreshAddons, 5000);

	if (motifySettings.checkForAddonUpdates) {
		addonLoader.requirePluginUpdate = function(plugin, latest) {
			displayNotificationBubble(`Plugin "${plugin.name}" has an update. Latest version is ${latest}, installed version is ${plugin.version}. Click this notification to view the update.`, "info", { timeout: 999999, onclick: e => {
				window.open(plugin.url);
				e.target.parentElement.remove();
			}});
		};

		addonLoader.requireThemeUpdate = function(theme, latest) {
			displayNotificationBubble(`Theme "${theme.name}" has an update. Latest version is ${latest}, installed version is ${theme.version}. Click this notification to view the update.`, "info", { timeout: 999999, onclick: e => {
				window.open(theme.url);
				e.target.parentElement.remove();
			}});
		};

		addonLoader.checkForPluginUpdate = async function(plugin) {
			let response = await fetch(plugin.url, { cache: "no-cache" });

			if (response.statusText != "OK") {
				console.error("[" + plugin.name + "]: Failed to check for update.");
				console.error({ Response: response });
				return;
			}

			response = await response.text();

			const versionIndex = response.indexOf("get version") == -1 ? response.indexOf("version") : response.indexOf("get version"), version = response.substring(versionIndex, response.length).split(/"|'/)[1].trim();

			if (plugin.version != version) this.requirePluginUpdate(plugin, version);
		};

		addonLoader.checkForThemeUpdate = async function(theme) {
			let response = await fetch(theme.url, { cache: "no-cache" });

			if (response.statusText != "OK") {
				console.error("[" + theme.name + "]: Failed to check for update.");
				console.error({ Response: response });
				return;
			}

			response = await response.text();

			const versionIndex = response.indexOf('"version"'), version = response.substring(versionIndex, response.length).split('"')[3].trim();

			if (theme.version != version) this.requireThemeUpdate(theme, version);
		};

		setTimeout(addonLoader.checkForUpdates = async function() {
			for (let pluginKey in motifyPlugins) {
				if (!addonLoader.enabledPlugins[pluginKey] || !motifyPlugins[pluginKey].url || addonLoader.updateChecked.includes(motifyPlugins[pluginKey].url)) continue;

				addonLoader.checkForPluginUpdate(motifyPlugins[pluginKey]);

				addonLoader.updateChecked.push(motifyPlugins[pluginKey].url);
			}

			for (let themeKey in motifyThemes) {
				if (!addonLoader.enabledThemes[themeKey] || !motifyThemes[themeKey].url || addonLoader.updateChecked.includes(motifyThemes[themeKey].url)) continue;

				addonLoader.checkForThemeUpdate(motifyThemes[themeKey]);

				addonLoader.updateChecked.push(motifyThemes[themeKey].url);
			}
		}, 5000);
	}

	addonLoader.callPluginEvent = function(eventName, ...args) {
		for (let name in window.motifyPlugins) {
			const plugin = window.motifyPlugins[name];
			if (typeof plugin[eventName] == "function") plugin[eventName](...args);
		}
	};

	addonLoader.callPluginEventOnPlugin = function(plugin, eventName, ...args) {
		if (typeof plugin[eventName] == "function") plugin[eventName](...args);
	};

	const lastStates = {};
	setInterval(async function() {
		if (motifySettings.developerMode) {
			for (let name in window.motifyPlugins) {
				MotifyAPI.readFile("motify/plugins/" + window.motifyPlugins[name].filename, async function(state) {
					if (!lastStates[window.motifyPlugins[name].filename]) return lastStates[window.motifyPlugins[name].filename] = state;
					if (lastStates[window.motifyPlugins[name].filename] != state) {
						if (typeof window.motifyPlugins[name].end == "function") window.motifyPlugins[name].end();
						addonLoader.loadPlugin(window.motifyPlugins[name].filename, state);
						console.log(window.motifyPlugins[name].filename + " reloaded.");
						lastStates[window.motifyPlugins[name].filename] = state;
					}
				});
			}

			for (let name in window.motifyThemes) {
				MotifyAPI.readFile("motify/themes/" + window.motifyThemes[name].filename, async function(state) {
					if (!lastStates[window.motifyThemes[name].filename]) return lastStates[window.motifyThemes[name].filename] = state;
					if (lastStates[window.motifyThemes[name].filename] != state) {
						window.motifyThemes[name].instance.destroy();
						addonLoader.loadTheme(window.motifyThemes[name].filename, state);
						console.log(window.motifyThemes[name].filename + " reloaded.");
						lastStates[window.motifyThemes[name].filename] = state;
					}
				})
			}
		}
	}, 1000);

	addonLoader.updateThemeSettings = function() {
		if (addonLoader.themeSettingsStyle) addonLoader.themeSettingsStyle.destroy();
		let settings = "";
		for (let setting in window.motifyThemeSettings)
			if (window.motifyThemeSettings[setting]) settings += (settings.endsWith(";") || !settings.length ? "" : ";") + setting + ":" + window.motifyThemeSettings[setting];
		addonLoader.themeSettingsStyle = MotifyAPI.injectCSS("motifyThemeSettings", `html{${settings}}`);
	};

	addonLoader.save = function() {
		localStorage.setItem("pluginSettings", JSON.stringify(window.motifyPluginSettings));
		localStorage.setItem("themeSettings", JSON.stringify(window.motifyThemeSettings));
		localStorage.setItem("enabledPlugins", JSON.stringify(addonLoader.enabledPlugins));
		localStorage.setItem("enabledThemes", JSON.stringify(addonLoader.enabledThemes));
	};

	addonLoader.getThemeVariables = function(c) {
		const match = c.match(/([^var\(]|^)--(.*?);/g),
			returnValue = {};
		if (!match) return {};
		for (let i = 0; i < match.length; i++) {
			const t = match[i].trim(),
				s = match[i].indexOf(":"),
				key = t.slice(0, s - 1).trim().toString(),
				value = t.slice(s + 1).split(";").join("").trim().toString();
			if (key && value) returnValue[key] = value;
		}
		return returnValue;
	};

})();
} catch(err) {
	throw err;
}