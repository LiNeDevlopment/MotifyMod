document.getElementByIdGlobal = function(id) {
	let found = document.getElementById(id);
	if(found) return found;
	for(let i = 0; i < documents.length; i++) if(found = documents[i].getElementById(id)) return found;
	return null;
};

document.getElementsByClassNameGlobal = function(cn) {
	const found = Array.from(document.getElementsByClassName(cn));
	for(let i = 0; i < documents.length; i++) {
		const foundHere = documents[i].getElementsByClassName(cn);
		for(let i = 0; i < foundHere.length; i++) found.push(foundHere[i]);
	}
	return found;
};

document.getElementsByTagNameGlobal = function(tn) {
	const found = Array.from(document.getElementsByTagName(tn));
	for(let i = 0; i < documents.length; i++) {
		const foundHere = documents[i].getElementsByTagName(tn);
		for(let i = 0; i < foundHere.length; i++) found.push(foundHere[i]);
	}
	return found;
};

window.globalEventListeners = [];

window.addGlobalEventListener = function(type, event) {
	for(let i = 0; i < documents.length; i++) {
		documents[i].addEventListener(type, event);
		window.globalEventListeners.push({ type : type, event : event });
	}
};

window.removeGlobalEventListener = function(type, event) {
	for(let i = 0; i < documents.length; i++) {
		documents[i].removeEventListener(type, event);
		const fi = window.globalEventListeners.findIndex(ev => ev.event == event);
		if(fi != -1) window.globalEventListeners.splice(fi, 1);
	}
};

function css(element) {

	const sheets = [], output = {};

	for(let doc of documents) for(let sheet of doc.styleSheets) sheets.push(sheet);

	for(let i = 0; i < sheets.length; i++) {

		const rules = sheets[i].cssRules;

		for(let r = 0; r < rules.length; r++) {
			if(element.matches(rules[r].selectorText)) {
				output[rules[r].selectorText] = rules[r].style.cssText.split(";").join(";\n");
			}
		}

	}

	if(element.style.cssText) output.style = element.style.cssText.split(";").join(";\n");

	return output;

}

function searchCSS(search, documents = window.documents) {
	const res = [], override = [];
	for(let doc of documents) {
		for(let sheet of doc.styleSheets) {
			for(let i = 0; i < sheet.rules.length; i++) {
				if(sheet.rules[i].cssText.toLowerCase().includes(search.toLowerCase())) {
					res.push({
						document : doc,
						sheet : sheet,
						ruleIdx : i,
						rule : sheet.rules[i],
						css : sheet.rules[i].cssText
					});
				}
			}
		}
	}
	for(let i = 0; i < res.length; i++) if(!override.includes(res[i])) override.push(res[i]);
	console.log({ Results : res, Override : Array.from(override.filter(o => o.rule.selectorText), o => o.rule.selectorText.trim()).join(", ") });
}

function displayNotificationBubble(content, type, options = {}) {
	const EVENT = SpotifyInternals.getModuleById(10);
	SpotifyInternals.getModuleById(9).dispatchEvent(new EVENT(EVENT.TYPES.SHOW_NOTIFICATION_BUBBLE, { i18n : content }));
};

var styleQueue = {};
window.EnhancedSpotifyAPI = {

	injectCSS : function(id, css) {

		const style = { destroy : function() { for(let doc of documents) if(doc.getElementById(id)) doc.getElementById(id).remove(); delete styleQueue[id]; } };

		for(let doc of documents) 
			if(!doc.getElementById(id)) doc.head.insertAdjacentHTML("beforeEnd", `<style id="${id}">${css}</style>`);
			else doc.getElementById(id).innerHTML = css;

		styleQueue[id] = () => EnhancedSpotifyAPI.injectCSS(id, css);

		return style;

	},

	readFile : function(filename, callback, options = {}) {

		const { async = true } = options;

		const xhr = new XMLHttpRequest();

		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
				callback(xhr.responseText);
			}
		};
		
		xhr.open("GET", filename, async);
		xhr.send(null);

	},

	createSettingsToggle : function(label, state, callback, options = {}) {
		const { description = "" } = options, element = document.createElement("div");
		element.className = "settings-row";
		element.style.marginTop = "20px";
		element.innerHTML = 
			`<label class="col description" style="position:relative" data-description="${description}">${label}</label>
			<div class="col action" style="float:right">
				<div role="checkbox" class="${state ? "enabled " : ""}slider">
					<div></div>
				</div>
			</div>`;
		element.lastElementChild.firstElementChild.addEventListener("click", function(e) {
			callback(!e.currentTarget.classList.contains("enabled"));
			if(e.currentTarget.classList.contains("enabled")) e.currentTarget.classList.remove("enabled");
			else e.currentTarget.classList.add("enabled");
		});
		return element;
	},

	createSettingsTextField : function(label, value, callback, options = {}) {
		const { type = "string", description = "" } = options, element = document.createElement("div");
		element.className = "settings-row";
		element.style.marginTop = "20px";
		element.innerHTML =
			`<label class="col description" style="position:relative" data-description="${description}">${label}</label>
			<input class="es-addon-textfield" value="${value}"/>`;
		let last = value;
		element.lastElementChild.addEventListener("focusout", function(e) {
			switch(type) {
				case "number" : case "float" : case "floating point" : {
					if(!e.target.value) {
						callback(e.target.value = last = 0);
						break;
					}
					if(isNaN(e.target.value)) {
						displayNotificationBubble("Value must be a number!", "error");
						e.target.value = last;
						break;
					}
					callback(last = parseFloat(e.target.value));
					break;
				}
				case "whole number" : case "int" : case "integer" : {
					if(!e.target.value) {
						callback(e.target.value = last = 0);
						break;
					}
					if(isNaN(e.target.value)) {
						displayNotificationBubble("Value must be a number!", "error");
						e.target.value = last;
						break;
					}
					callback(last = e.target.value = parseInt(e.target.value));
				}
				default : callback(last = e.target.value);
			}
		});
		return element;
	}

};

window.enhancedSpotifySettings = {
	developerMode : true,
	logBridgeRequests : false,
	logLocalBridgeRequests : false,
	logEventListeners : false
};

window.saveSettings = function() { window.localStorage.setItem("enhancedSpotifySettings", JSON.stringify(window.enhancedSpotifySettings)); };

try {
	let saved = window.localStorage.getItem("enhancedSpotifySettings");
	if(saved) {
		saved = JSON.parse(saved);
		for(let setting in saved) window.enhancedSpotifySettings[setting] = saved[setting];
	}
} finally {
	window.saveSettings();
}

window.observer = new MutationObserver(function(mutations) {
	for(let m = 0; m < mutations.length; m++) {
		const mutation = mutations[m];
		for(let i = 0; i < mutation.addedNodes.length; i++) {
			const added = mutation.addedNodes[i];
			if(typeof window.addonLoader != "undefined") addonLoader.callPluginEvent("onNodeAdded", added);
			if(added.localName == "section" && added.children[0].children[0].innerText == "Language") {
				onSettingsLoaded(document.getElementByIdGlobal("settings"));
			}
		}
		for(let i = 0; i < mutations.removedNodes.length; i++) {
			const removed = mutation.addedNodes[i];
			if(typeof window.addonLoader != "undefined") addonLoader.callPluginEvent("onNodeRemoved", removed);
		}
	}
});

let shouldLoadPluginSettings = false;

function onSettingsLoaded(menu) {

	try {

		const getAddonItemHTML = function(item, enabled, type) {
			return `<div class="section-divider es-addon-item${!enabled ? " is-disabled" : ""}">
				<h2 data-creator="${item.creator || "Unknown User"}">${item.name}</h2>
				${typeof item.settingFields != "undefined" && Object.keys(item.settingFields).length || type == "theme" && Object.keys(addonLoader.getThemeVariables(item.data)).length ? `<div class="material-icons es-addon-settings-button">settings</div>` : ""}
				<div class="col action" style="float:right">
					<div role="checkbox" class="${enabled ? "enabled " : ""}slider">
						<div></div>
					</div>
				</div>
				<label class="col description" style="font-weight:lighter;margin-top:5px;width:100%">${item.description || ""}</label>
				<div class="es-addon-settings">

				</div>
			</div>`;
		};

		const addAddonItem = function(settings, item, type) {

			const html = getAddonItemHTML(item, type == "plugin" ? addonLoader.enabledPlugins[item.keyName] : addonLoader.enabledThemes[item.keyName], type);

			settings.insertAdjacentHTML("beforeEnd", html);
			
			const element = settings.lastChild, settingsButton = element.getElementsByClassName("es-addon-settings-button")[0], toggleButton = element.getElementsByClassName("col action")[0];

			let animating = false;

			const openAddonSettings = pop => {
				if(animating) return;
				animating = true;
				element.classList.add("settings-opened", "settings-opened-" + item.keyName);
				closedHeight = element.offsetHeight;
				pop();
				const openedHeight = element.offsetHeight;
				element.insertAdjacentHTML("beforeBegin", `
					<style id="es-settings-style-opening-${item.keyName}">
						.es-addon-item.settings-opened-${item.keyName} {
							height: ${closedHeight}px;
							animation: settings-opening-${item.keyName} 0.5s forwards;
						}
						@keyframes settings-opening-${item.keyName} {
							0% { height: ${closedHeight}px; }
							100% { height: ${openedHeight}px; }
						}
					</style>
				`);
				setTimeout(() => {
					animating = false;
					document.getElementByIdGlobal("es-settings-style-opening-" + item.keyName).remove();
				}, 500);
			};

			const closeAddonSettings = () => {
				if(animating) return;
				animating = true;
				const openedHeight = element.offsetHeight;
				element.insertAdjacentHTML("beforeBegin", `
					<style id="es-settings-style-closing-${item.keyName}">
						.es-addon-item.settings-opened-${item.keyName} {
							height: ${openedHeight}px;
							animation: settings-closing-${item.keyName} 0.5s forwards;
						}
						@keyframes settings-closing-${item.keyName} {
							0% { height: ${openedHeight}px; }
							100% { height: ${closedHeight}px; }
						}
					</style>
				`);
				element.classList.remove("settings-opened");
				setTimeout(() => {
					animating = false;
					document.getElementByIdGlobal("es-settings-style-closing-" + item.keyName).remove();
					element.getElementsByClassName("es-addon-settings")[0].innerHTML = "";
					element.classList.remove("settings-opened-" + item.keyName);
				}, 500);
			};

			if(settingsButton)  {
				if(type == "plugin") settingsButton.addEventListener("click", function() {
					if(!element.classList.contains("settings-opened")) {
						openAddonSettings(() => {
							for(let field in item.settingFields) {
								try{

									let repop, array, insertDeleteButton;

									if(item.settingFields[field].array || item.settingFields[field].list) {

										const list = document.createElement("div");
										list.className = "es-addon-setting-array";
										list.innerHTML = `<label class="col description" data-description="${item.settingFields[field].description || ""}">${item.settingFields[field].label}</label><div class="es-addon-settings-array-items" style="margin:5px">`;

										array = list.getElementsByClassName("es-addon-settings-array-items")[0];

										if(item.settingFields[field].array) {

											const addButton = document.createElement("button"), clearButton = document.createElement("button");
											addButton.className = clearButton.className = "button button-with-stroke";
											addButton.style = clearButton.style = "margin: 10px";

											addButton.textContent = "Add";
											addButton.addEventListener("click", () => {
												item.settings[field].push("");
												array.innerHTML = "";
												addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field + ".add");
												repop();
												addonLoader.save();
											});

											clearButton.textContent = "Clear";
											clearButton.addEventListener("click", () => {
												addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field + ".clear", item.settings[field], item.settings[field] = []);
												array.innerHTML = "";
												repop();
												addonLoader.save();
											});

											insertDeleteButton = i => {
												array.lastElementChild.insertAdjacentHTML("afterBegin", `<span class="material-icons" style="float:right;cursor:pointer">close</span>`);
												array.lastElementChild.firstElementChild.addEventListener("click", () => {
													addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field + ".remove", item.settings[field][i]);
													item.settings[field].splice(i, 1);
													array.innerHTML = "";
													repop();
													addonLoader.save();
												});
											};

											list.appendChild(addButton);
											list.appendChild(clearButton);

										}

										element.lastElementChild.appendChild(list);

									}
									switch(item.settingFields[field].type ? item.settingFields[field].type : null) {
										case null : case "bool" : case "boolean" : {
											if(array) {
												(repop = () => {
													for(let i in item.settings[field]) {
														array.appendChild(EnhancedSpotifyAPI.createSettingsToggle(i, item.settings[field][i], () => {
															addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field + "[" + i + "]", item.settings[field][i], item.settings[field][i] = !item.settings[field][i]);
															addonLoader.save();
														}));
														if(item.settingFields[field].array) insertDeleteButton(i);
													}
												})();
											} else {
												element.lastElementChild.appendChild(EnhancedSpotifyAPI.createSettingsToggle(item.settingFields[field].label, item.settings[field], () => {
													addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field, item.settings[field], item.settings[field] = !item.settings[field]);
													addonLoader.save();
												}, { description : item.settingFields[field].description }));
											}
											break;
										}
										case "custom" : {
											if(array) {
												(repop = () => {
													for(let i in item.settings[field]) {
														if(typeof item.settingFields[field].element == "function") {
															array.appendChild(item.settingFields[field].element(item, value => {
																addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field + "[" + i + "]", item.settings[field] = value);
																addonLoader.save();
															}));
															if(item.settingFields[field].array) insertDeleteButton(i);
														} else if(item.settingFields[field].html) {
															element.lastElementChild.insertAdjacentHTML("beforeEnd", item.settingFields[field].html);
															if(item.settingFields[field].array) insertDeleteButton(i);
														}
													}
												})();
											} else {
												if(typeof item.settingFields[field].element == "function") {
													element.lastElementChild.appendChild(item.settingFields[field].element(item, value => {
														addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field, item.settings[field], item.settings[field] = value);
														addonLoader.save();
													}));
												}
												if(item.settingFields[field].html) element.lastElementChild.insertAdjacentHTML("beforeEnd", item.settingFields[field].html);
											}
											break;
										}
										default : {
											if(array) {
												(repop = () => {
													for(let i in item.settings[field]) {
														array.appendChild(EnhancedSpotifyAPI.createSettingsTextField(i, item.settings[field][i], e => {
															addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field + "[" + i + "]", item.settings[field][i], item.settings[field][i] = e);
															addonLoader.save();
														}, { type : item.settingFields[field].type }));
														if(item.settingFields[field].array) insertDeleteButton(i);
													}
												})();
											} else {
												element.lastElementChild.appendChild(EnhancedSpotifyAPI.createSettingsTextField(item.settingFields[field].label, item.settings[field], e => {
													addonLoader.callPluginEventOnPlugin(item, "onSettingChanged", field, item.settings[field], item.settings[field] = e);
													addonLoader.save();
												}, { type : item.settingFields[field].type, description : item.settingFields[field].description }));
											}
										}
									}
								} catch(err) { console.error({ "Error loading setting field" : err }); }
							}
						});
					} else closeAddonSettings();
				});
				else settingsButton.addEventListener("click", function() {
					if(!element.classList.contains("settings-opened")) {
						openAddonSettings(() => {
							const variables = addonLoader.getThemeVariables(item.data);
							for(let variable in variables) {
								try {
									element.lastElementChild.appendChild(EnhancedSpotifyAPI.createSettingsTextField(variable, window.esThemeSettings[variable] || "", set => {
										window.esThemeSettings[variable] = set;
										addonLoader.updateThemeSettings();
										addonLoader.save();
									}, { description : "Default: " + variables[variable] }));
								} catch(err) { console.error({ "Error loading setting field" : err }); }
							}
						});
					} else closeAddonSettings();
				});
			}

			toggleButton.addEventListener("click", function() {
				if(type == "plugin") {
					if(addonLoader.enabledPlugins[item.keyName]) {
						if(typeof item.end == "function") item.end();
						addonLoader.enabledPlugins[item.keyName] = false;
					} else {
						if(typeof item.init == "function") item.init();
						addonLoader.enabledPlugins[item.keyName] = true;
					}
				} else {
					if(addonLoader.enabledThemes[item.keyName]) {
						if(item.instance) item.instance.destroy();
						addonLoader.enabledThemes[item.keyName]  = false;
					} else {
						item.instance = EnhancedSpotifyAPI.injectCSS(item.keyName, item.data);
						addonLoader.enabledThemes[item.keyName] = true;
					}
				}
				if(element.classList.contains("is-disabled")) element.classList.remove("is-disabled");
				else element.classList.add("is-disabled");
				if(toggleButton.firstElementChild.classList.contains("enabled")) toggleButton.firstElementChild.classList.remove("enabled");
				else toggleButton.firstElementChild.classList.add("enabled");
				addonLoader.save();
			});

		};

		if(shouldLoadPluginSettings) {

			for(let sect of menu.children) sect.style.display = "none";

			const settings = document.createElement("section");
			settings.id = "es-plugin-settings";

			for(let name in window.esPlugins) addAddonItem(settings, window.esPlugins[name], "plugin");

			menu.appendChild(settings);

			document.getElementsByClassNameGlobal("glue-page-header__title-text")[0].textContent = "Enhanced Spotify Plugins";

			shouldLoadPluginSettings = false;

		} else if(window.shouldLoadThemeSettings) {

			for(let sect of menu.children) sect.style.display = "none";

			const items = document.createElement("section");
			items.id = "es-theme-settings";

			for(let name in window.esThemes) addAddonItem(items, window.esThemes[name], "theme");

			menu.appendChild(items);

			document.getElementsByClassNameGlobal("glue-page-header__title-text")[0].textContent = "Enhanced Spotify Themes";

			shouldLoadThemeSettings = false;

		} else {

			if(document.getElementByIdGlobal("es-plugin-settings")) document.getElementByIdGlobal("es-plugin-settings").remove();
			if(document.getElementByIdGlobal("es-theme-settings")) document.getElementByIdGlobal("es-theme-settings").remove();
			for(let sect of menu.children) sect.style.display = "";
			if(!document.getElementByIdGlobal("es-settings")) {

				const settings = document.createElement("section");
				settings.id = "es-settings";
				settings.innerHTML = `
					<div class="section-divider">
						<h2>Enhanced Spotify</h2>
					</div>
				`;

				settings.appendChild(EnhancedSpotifyAPI.createSettingsToggle("Developer mode", enhancedSpotifySettings.developerMode, bool => {
					enhancedSpotifySettings.developerMode = bool;
					saveSettings();
				}));

				settings.appendChild(EnhancedSpotifyAPI.createSettingsToggle("Log unblocked bridge requests to console", enhancedSpotifySettings.logBridgeRequests, bool => {
					enhancedSpotifySettings.logBridgeRequests = bool;
					saveSettings();
				}));

				settings.appendChild(EnhancedSpotifyAPI.createSettingsToggle("Log local bridge requests to console", enhancedSpotifySettings.logLocalBridgeRequests, bool => {
					enhancedSpotifySettings.logLocalBridgeRequests = bool;
					saveSettings();
				}));

				settings.appendChild(EnhancedSpotifyAPI.createSettingsToggle("Log added event listeners", enhancedSpotifySettings.logEventListeners, bool => {
					enhancedSpotifySettings.logEventListeners = bool;
					saveSettings();
				}));

				document.getElementByIdGlobal("basic-settings").insertBefore(settings, document.getElementByIdGlobal("language"));

			}

			document.getElementsByClassNameGlobal("glue-page-header__title-text")[0].textContent = "Settings";

		}

		addonLoader.callPluginEvent("onSettingsMenu", menu);

	} catch(err) { console.error({ "onSettingsLoaded Error" : err }); }

}

document.addEventListener("click", function(e) {

	if(e.target.id == "profile-menu-toggle" && document.getElementsByClassName("GlueMenu__root-items").length) {

		const settingsButton = document.querySelector('[data-menu-item="settings"]');
		if(!settingsButton) return;

		settingsButton.outerHTML = `
			<button id="es-plugins-button" class="GlueMenuItem" role="menuitem" data-submenu="false">ES Plugins</button>
			<button id="es-themes-button" class="GlueMenuItem" role="menuitem" data-submenu="false">ES Themes</button>
			${settingsButton.outerHTML}
		`;

		const glueMenuItems = document.getElementsByClassName("GlueMenuItem"), pluginsButton = document.getElementById("es-plugins-button"), themesButton = document.getElementById("es-themes-button");
		for(let i = 0; i < glueMenuItems.length; i++) {

			glueMenuItems[i].addEventListener("mouseover", () => {
				for(let hovered of document.getElementsByClassName("GlueMenuItem")) hovered.classList.remove("selected");
				glueMenuItems[i].classList.add("selected");
			});

			glueMenuItems[i].addEventListener("mouseleave", () => {
				glueMenuItems[i].classList.remove("selected");
			});

			if(glueMenuItems[i].dataset.menuItem == "settings") {
				glueMenuItems[i].addEventListener("click", function() {
					if(document.getElementByIdGlobal("settings")) onSettingsLoaded(document.getElementByIdGlobal("settings"));
				});
			}

		}

		pluginsButton.addEventListener("click", function() {
			shouldLoadPluginSettings = true;
			if(document.getElementByIdGlobal("settings")) onSettingsLoaded(document.getElementByIdGlobal("settings"));
			const event = SpotifyInternals.getModuleById(10);
			SpotifyInternals.getModuleById(9).dispatchEvent(new event(event.TYPES.NAVIGATION_OPEN_URI, "spotify:app:settings"));
			document.getElementById("profile-menu-toggle").click();
		});

		themesButton.addEventListener("click", function() {
			window.shouldLoadThemeSettings = true;
			if(document.getElementByIdGlobal("settings")) onSettingsLoaded(document.getElementByIdGlobal("settings"));
			const event = SpotifyInternals.getModuleById(10);
			SpotifyInternals.getModuleById(9).dispatchEvent(new event(event.TYPES.NAVIGATION_OPEN_URI, "spotify:app:settings"));
			document.getElementById("profile-menu-toggle").click();
		});

	}

});

var documents = [document], windows = [window];

(window.patchWindow = async function(w){

	(function(){

		const unpatched = {
			addEventListener : w.HTMLElement.prototype.addEventListener,
			removeEventListener : w.HTMLElement.prototype.removeEventListener
		};

		const eventListeners = {};

		w.Element.prototype.addEventListener = function() {

			unpatched.addEventListener.apply(this, arguments);

			if(!eventListeners[this]) eventListeners[this] = {};
			if(!eventListeners[this][arguments[0]]) eventListeners[this][arguments[0]] = {};
			eventListeners[this][arguments[0]] = [arguments[1]];
			this.eventListeners = eventListeners[this];

			const logObj = {};

			logObj[(this.id || this.className || this.nodeName) + "." + arguments[0]] = {
				type : arguments[0],
				event : arguments[1],
				keys : Object.keys(this),
				convertedKeys : Array.from(Object.keys(this), key => this[key]),
				element : this
			};
			
			if(enhancedSpotifySettings.logEventListeners) console.log(logObj);

		};

		w.Element.prototype.removeEventListener = function() {

			unpatched.removeEventListener.apply(this, arguments);

			try { delete eventListeners[this][arguments[0]]; } finally{}
			this.eventListeners = eventListeners[this];

		};

	})();

	const timeout = performance.now();
	while(typeof w.__spotify == "undefined" && performance.now() - timeout < 5000) await new Promise(p => setTimeout(p, 0));
	if(performance.now() - timeout > 5000) return;

	w.__spotify.product_state.catalogue = "premium";
	w.__spotify.product_state["app-developer"] = 1; //likely all do nothing.
	w.__spotify.developer_mode = true;

	w.onerror = function() {
		const errorMessage = {};
		errorMessage[w.name + ".onerror"] = arguments;
		console.log(errorMessage);
	};

	const unpatchedBridgeRequest = w._getSpotifyModule("bridge").executeRequest;

	w._getSpotifyModule("bridge").executeRequest = function() {

		const obj = {}, data = JSON.parse(arguments[0]), uri = data.args && data.args[1] && data.args[1].uri ? data.args[1].uri : null;

		const unpatchedSuccess = arguments[1].onSuccess;
		if(unpatchedSuccess) arguments[1].onSuccess = e => {
			try{
				const parsed = JSON.parse(e);
				if(uri) {
					const o = {};
					o["Success for " + uri] = parsed;
					if(enhancedSpotifySettings.logBridgeRequests) console.log(o);
				}
			} catch(err) { console.error({ error : err }); }
			unpatchedSuccess(e);
		};

		if(!uri && !enhancedSpotifySettings.logLocalBridgeRequests) return unpatchedBridgeRequest.apply(w, arguments);

		obj[(uri ? "Bridge" : "Local Bridge") + " Request (" + (uri || data.name || "unknown") + ")"] = {
			data : data,
			events : arguments[1]
		};

		if(enhancedSpotifySettings.logBridgeRequests) console.log(obj);

		return unpatchedBridgeRequest.apply(w, arguments);

	};

	console.log({ "Patched" : w.location.href });

})(window);

window.ReactData = {

	get : function(element) {
		if(!(element instanceof Element)) return null;
		return element[Object.keys(element).find(key => key.startsWith("__reactInternalInstance"))];
	},

	getEvents : function(element) {
		if(!(element instanceof Element)) return null;
		return element[Object.keys(element).find(key => key.startsWith("__reactEventHandlers"))];
	},

	getOwner : function(element) {

		if(!(element instanceof Element)) return null;
		
		const reactData = this.get(element);

		if(reactData == undefined) return null;

		for(let c = reactData.return; !_.isNil(c); c = c.return) {
			if(_.isNil(c)) continue;
			const owner = c.stateNode;
			if(!_.isNil(owner) && !(owner instanceof HTMLElement)) return owner;
		}

	},

	getProps : function(element) {

		if(!(element instanceof Element)) return null;

		const owner = this.getOwner(element);

		return owner ? owner.props : null;

	},

	getProp : function(element, propKey) {

		if(!(element instanceof Element)) return null;

		const owner = this.getOwner(element);

		if(!owner || !owner.props) return null;

		const split = propKey.split("."), obj = owner.props;

		for(let i = 0; i < split.length; i++) {
			obj = obj[split[i]];
			if(!obj) return null;
		}

		return obj;

	},

};

window.onAppLoaded = function(appWindow, appDocument) {
	console.log({ "App loaded" : appWindow.name = appWindow.location.href.match(/:\/\/[^\.]+\./)[0].match(/[a-z]/g).join("") });
	windows.push(appWindow);
	appDocument.body.id = "root";
	appDocument.body.classList.add("es-doc-" + appWindow.name);
	documents.push(appDocument);
	observer.observe(appDocument, { childList : true, subtree : true });
	overrideConsole(appWindow);
	patchWindow(appWindow);
	for(let id in styleQueue) styleQueue[id]();
	for(let i = 0; i < window.globalEventListeners.length; i++) appDocument.addEventListener(window.globalEventListeners[i].type, window.globalEventListeners[i].event);
	if(typeof window.addonLoader != "undefined") addonLoader.callPluginEvent("onAppLoaded", appWindow, appDocument);
};

observer.observe(document, { childList : true, subtree : true });

(async function(){
	while(document.body == null) await new Promise(p => setTimeout(p, 0));
	window.name = "zlink";
	document.body.insertAdjacentHTML("afterBegin", `<div id="app-background" style="z-index:-10000;position:fixed;top:0;left:0;right:0;bottom:0"></div>`);
	document.body.id = "zlink-root";
	document.body.classList.add("es-doc-zlink");
})();

EnhancedSpotifyAPI.readFile("enhancedspotify/main.css", css => EnhancedSpotifyAPI.injectCSS("esMain", css));
EnhancedSpotifyAPI.readFile("enhancedspotify/console.css", css => EnhancedSpotifyAPI.injectCSS("esConsole", css));
EnhancedSpotifyAPI.readFile("https://fonts.googleapis.com/icon?family=Material+Icons", css => EnhancedSpotifyAPI.injectCSS("materialIcons", css));

addGlobalEventListener("keydown", function(e) {
	if(e.ctrlKey && e.shiftKey && e.key == "I" || e.key == "F12") {
		if(console.element.style.display) console.element.style.display = "";
		else console.element.style.display = "none";
	}
});

(function(){

	let last = "";

	setInterval(function() {
		EnhancedSpotifyAPI.readFile("enhancedspotify/runtime.js", current => {
			if(last != current) {
				eval(current);
				last = current;
			}
		})
	}, 1000);

})();

window.initModuleGetter = function(t, n) {

	const cachedModules = {};

	for(let i in t) if(t[i].exports) t[i].exports.moduleId = i;

	window.SpotifyInternals = {
		modules : t,
		getModuleById : n,
		findModule : function(filter, options = {}) {
			const { returnModule = true, suppressWarning = false } = options;
			for(let i in t) {
				if(t.hasOwnProperty(i)) {
					const m = t[i].exports;
					if(m && m.__esModule && m.default && filter(m.default)) return returnModule ? m.default : t[i];
					if(m && filter(m)) return m;
				}
			}
			if(!suppressWarning) console.warn("No module found by this filter!", filter);
			return null;
		},
		findModules : function(filter, options = {}) {
			const { returnModule = true, suppressWarning = false } = options, found = [];
			for(let i in t) {
				if(t.hasOwnProperty(i)) {
					const m = t[i].exports;
					if(m && m.__esModule && m.default && filter(m.default)) found.push(returnModule ? m.default : t[i]);
					else if(m && filter(m)) found.push(m);
				}
			}
			return found;
		},
		getModuleByProps : function(props) {
			const cacheKey = props.join(",");
			if(!cachedModules[cacheKey]) cachedModules[cacheKey] = this.findModule(module => props.every(prop => module[prop]));
			return cachedModules[cacheKey];
		},
		getModuleByProp : function(prop) {
			if(!cachedModules[prop]) cachedModules[prop] = this.findModule(module => module[prop]);
			return cachedModules[prop];
		}
	};

	window.searchModules = function(search) { //Use this for debugging, so you can find what props you're looking for. Do not use this for getting modules in plugins.
		const found = {};
		SpotifyInternals.findModule(module => {
			for(let key in module) if(!found[key] && key.toLowerCase().includes(search.toLowerCase())) found[key] = module;
			for(let key in module.__proto__) if(!found[key] && key.toLowerCase().includes(search.toLowerCase())) found[key] = module;
		}, { suppressWarning : true });
		console.log({ "Found Modules" : found });
	};

};

(window.addonLoader = function() {

	window.esPlugins = {};
	window.esThemes = {};

	window.esPluginSettings = JSON.parse(localStorage.getItem("pluginSettings")) || {};
	window.esThemeSettings = JSON.parse(localStorage.getItem("themeSettings")) || {};

	addonLoader.enabledPlugins = JSON.parse(localStorage.getItem("enabledPlugins")) || {};
	addonLoader.enabledThemes = JSON.parse(localStorage.getItem("enabledThemes")) || {};

	addonLoader.loadPlugin = async function(name, data) {
		try {
			const plugin = eval(`(function(){${data}})();`), key = name.split(".")[0];
			if(typeof plugin.name == "undefined") plugin.name = key;
			plugin.keyName = key;
			plugin.filename = name;
			window.esPlugins[key] = plugin;
			if(addonLoader.enabledPlugins[key] == undefined) {
				addonLoader.enabledPlugins[key] = true;
				addonLoader.save();
			}
			if(plugin.defaultSettings != undefined) {
				plugin.settings = plugin.defaultSettings;
				if(window.esPluginSettings[key]) for(let saved in window.esPluginSettings[key]) plugin.settings[saved] = window.esPluginSettings[key][saved];
				window.esPluginSettings[key] = plugin.settings;
				addonLoader.save();
			}
			while(typeof window.SpotifyInternals == "undefined" || typeof console.element == "undefined") await new Promise(p => setTimeout(p, 0));
			if(addonLoader.enabledPlugins[key]) if(typeof plugin.init == "function") plugin.init();
			console.log(name + " loaded.");
		} catch(err) {
			console.error({ "Error Loading Plugin" : { Plugin : name, Error : err } });
			alert("Error Loading " + name + ":\n" + err);
		}
	};

	addonLoader.loadTheme = async function(name, data) {
		try {
			const key = name.split(".")[0];
			window.esThemes[key] = {
				name : key,
				keyName : key,
				filename : name,
				data : data
			};
			if(data.toLowerCase().includes("themeinfo")) {
				try {
					const td = JSON.parse("{" + data.split("{").join("}").split("}")[1].trim() + "}");
					for(let k in td) {
						if(k != "filename" && k != "settings" && k != "data") {
							window.esThemes[key][k] = td[k];
						}
					}
				} catch(err) { console.errror({ "Error parsing theme info" : err }); }
			}
			const variables = addonLoader.getThemeVariables(data);
			for(let variable in variables) if(window.esThemeSettings[variable] == undefined) window.esThemeSettings[variable] = variables[variable].split(";")[0];
			if(addonLoader.enabledThemes[key] == undefined) {
				addonLoader.enabledThemes[key] = true;
				addonLoader.save();
			}
			if(addonLoader.enabledThemes[key]) window.esThemes[key].instance = EnhancedSpotifyAPI.injectCSS(key, data);
			addonLoader.updateThemeSettings();
			console.log(name + " loaded.");
		} catch(err) {
			console.error({ "Error Loading Theme" : { Theme : name, Error : err } });
			alert("Error Loading " + name + ":\n" + err);
		}
	};

	(addonLoader.refreshAddons = function() {
		EnhancedSpotifyAPI.readFile("enhancedspotify/addons.json", async function(raw) {
			const data = JSON.parse(raw);
			for(let i = 0; i < data.plugins.length; i++) {
				if(window.esPlugins[data.plugins[i].split(".")[0]]) continue;
				EnhancedSpotifyAPI.readFile("enhancedspotify/plugins/" + data.plugins[i], function(pluginData) {
					addonLoader.loadPlugin(data.plugins[i], pluginData);
				}, { async : false });
			}
			for(let i = 0; i < data.themes.length; i++) {
				if(window.esThemes[data.themes[i].split(".")[0]]) continue;
				EnhancedSpotifyAPI.readFile("enhancedspotify/themes/" + data.themes[i], function(themeData) {
					addonLoader.loadTheme(data.themes[i], themeData);
				}, { async : false });
			}
		});
	})();
	setInterval(addonLoader.refreshAddons, 5000);

	addonLoader.callPluginEvent = function(eventName, ...args) {
		for(let name in window.esPlugins) {
			const plugin = window.esPlugins[name];
			if(typeof plugin[eventName] == "function") plugin[eventName](...args);
		}
	};

	addonLoader.callPluginEventOnPlugin = function(plugin, eventName, ...args) {
		if(typeof plugin[eventName] == "function") plugin[eventName](...args);
	};

	const lastStates = {};
	setInterval(async function() {

		if(enhancedSpotifySettings.developerMode) {

			for(let name in window.esPlugins) {
				EnhancedSpotifyAPI.readFile("enhancedspotify/plugins/" + window.esPlugins[name].filename, async function(state) {
					if(!lastStates[window.esPlugins[name].filename]) return lastStates[window.esPlugins[name].filename] = state;
					if(lastStates[window.esPlugins[name].filename] != state) {
						if(typeof window.esPlugins[name].end == "function") window.esPlugins[name].end();
						addonLoader.loadPlugin(window.esPlugins[name].filename, state);
						console.log(window.esPlugins[name].filename + " reloaded.");
						lastStates[window.esPlugins[name].filename] = state;
					}
				});
			}

			for(let name in window.esThemes) {
				EnhancedSpotifyAPI.readFile("enhancedspotify/themes/" + window.esThemes[name].filename, async function(state) {
					if(!lastStates[window.esThemes[name].filename]) return lastStates[window.esThemes[name].filename] = state;
					if(lastStates[window.esThemes[name].filename] != state) {
						window.esThemes[name].instance.destroy();
						addonLoader.loadTheme(window.esThemes[name].filename, state);
						console.log(window.esThemes[name].filename + " reloaded.");
						lastStates[window.esThemes[name].filename] = state;
					}
				})
			}

		}

	}, 1000);

	addonLoader.updateThemeSettings = function() {
		if(addonLoader.themeSettingsStyle) addonLoader.themeSettingsStyle.destroy();
		let settings = "";
		for(let setting in window.esThemeSettings) if(window.esThemeSettings[setting]) settings += (settings.endsWith(";") || !settings.length ? "" : ";") + setting + ":" + window.esThemeSettings[setting];
		addonLoader.themeSettingsStyle = EnhancedSpotifyAPI.injectCSS("esThemeSettings", `html{${settings}}`);
	};

	addonLoader.save = function() {
		localStorage.setItem("pluginSettings", JSON.stringify(window.esPluginSettings));
		localStorage.setItem("themeSettings", JSON.stringify(window.esThemeSettings));
		localStorage.setItem("enabledPlugins", JSON.stringify(addonLoader.enabledPlugins));
		localStorage.setItem("enabledThemes", JSON.stringify(addonLoader.enabledThemes));
	};

	addonLoader.getThemeVariables = function(c) {
		const match = c.match(/([^var\(]|^)--(.*?);/g), returnValue = {};
		if(!match) return {};
		for(let i = 0; i < match.length; i++) {
			const t = match[i].trim(), s = match[i].indexOf(":"), key = t.slice(0, s - 1).trim().toString(), value = t.slice(s + 1).split(";").join("").trim().toString();
			if(key && value) returnValue[key] = value;
		}
		return returnValue;
	};

})();