console.history = [];
console.lastHistoryIdx = -1;
console.element = document.getElementsByClassName("es-console")[0];
console.field = console.element.getElementsByTagName("input")[0];

console.field.addEventListener("keydown", function(e) {

	if(e.target.value && e.key == "Enter") {

		console.history.push(e.target.value);
		console.lastHistoryIdx = -1;

		try {
			const obj = {};
			obj[e.target.value] = eval(e.target.value);
			console.log(obj);
		}
		catch(err) { console.error(err); }
		e.target.value = "";

	}

	else if(e.key == "ArrowUp") {
		if(console.lastHistoryIdx == -1) console.lastHistoryIdx = console.history.length;
		e.target.value = console.history[console.lastHistoryIdx -= 1] || "";
		if(!e.target.value) console.lastHistoryIdx = -1;
		e.preventDefault();
	}

	else if(e.key == "ArrowDown") {
		e.target.value = console.history[console.lastHistoryIdx += 1] || "";
		if(!e.target.value) console.lastHistoryIdx = -1;
		e.preventDefault();
	}

});

function createDomObj(element, parent) {

	const re = /<[^>]+>/g, rem = element.outerHTML.match(re);
	if(!rem) return;

	const item = document.createElement("div");

	if(!parent.className.includes("scroller dom")) item.style.marginLeft = "20px";
	else rem[0] = element.ownerDocument.location.href.match(/:\/\/[^\.]+\./)[0].match(/[a-z-]/g).join("") + ".html: " + rem[0];

	item.appendChild(document.createTextNode(rem[0]));

	const regex = {
		tag : /(<|<\/)+[a-z]+/
	};

	//while(regex.tag.test(item.innerHTML)) console.log(item.innerHTML = item.innerHTML.split(regex.tag).join(`<span style="color:blue">${RegExp.lastMatch.match(/[a-z]+/)}</span>`));

	item.referenceElement = element;

	const before = window.getComputedStyle(element, ":before").getPropertyValue("content"), after = window.getComputedStyle(element, ":after").getPropertyValue("content");

	if(before != undefined && before != "none") item.classList.add("hasBefore");
	if(after != undefined && after != "none") item.classList.add("hasAfter");

	if(element.children.length) {

		const more = document.createElement("span");

		more.style = "opacity:0.5;cursor:pointer";

		more.textContent = " . . . ";

		more.onclick = function() {
			more.textContent = "";
			for(let i = 0; i < element.children.length; i++) {
				createDomObj(element.children[i], more);
			}
			more.onclick = null;
		};

		item.appendChild(more);

	}

	item.onclick = function(e) {
		if(e.target != item) return;
		for(let a of document.getElementsByClassNameGlobal("es-selected")) a.classList.remove("es-selected");
		item.classList.add("es-selected");
		window.$0 = element;
		const css = window.css(element), styles = console.element.getElementsByClassName("dom-styles")[0];
		styles.innerHTML = "";
		for(let rule in css) {
			const element = document.createElement("div");
			element.className = "rule";
			element.textContent = rule;
			element.style.color = "#1DB954";
			element.insertAdjacentHTML("beforeEnd", `
				<span class="opening-bracket"> {</span>
					<div class="inner-style" style="color:white;margin-left:20px">${css[rule].split("\n").join("<br>")}</div>
				<div class="ending-bracket">}</div>
			`);
			styles.appendChild(element);
		}
	};

	item.onmouseenter = function() {
		for(let h of document.getElementsByClassNameGlobal("es-hovered")) h.classList.remove("es-hovered");
		element.classList.add("es-hovered");
	};

	item.onmouseleave = function() {
		element.classList.remove("es-hovered");
	};
	
	item.appendChild(document.createTextNode(rem[rem.length - 1]));

	parent.appendChild(item);

	return item;

}

function print(color) {

	try{

		const scroller = console.element.getElementsByClassName("scroller console")[0];

		const createObjectButtons = function(obj, parent) {
			
			const keys = [];
			for(let key in obj) keys.push(key);

			for(let i = 0; i < keys.length; i++) {
				
				const button = document.createElement("div"), buttonTitle = document.createElement("span"), buttonContent = document.createElement("div");

				button.appendChild(buttonTitle);
				button.appendChild(buttonContent);
				
				buttonTitle.textContent = keys[i];
				if(color != "default") buttonTitle.style.color = color;

				if(parent) button.style.marginLeft = "20px";

				const subKeys = [];
				if(typeof obj[keys[i]] == "object") for(let key in obj[keys[i]]) subKeys.push(key);

				if(subKeys.length) {
					buttonTitle.innerHTML += ` (<span style="color:white">${subKeys.length}</span>)`;
					button.className = "obj";
					let clickEvent;
					buttonTitle.onclick = clickEvent = function() {
						createObjectButtons(obj[keys[i]], buttonContent);
						buttonTitle.onclick = function() {
							while(buttonContent.children.length) buttonContent.removeChild(buttonContent.children[0]);
							buttonTitle.onclick = clickEvent;
						};
					};
				} else if(obj[keys[i]] != undefined && obj[keys[i]].toString().length > 999) {
					let createElipsis;
					(createElipsis = function() {
						const span = document.createElement("span");
						span.style = "color:white;opacity:0.5;cursor:pointer";
						span.textContent = ": . . .";
						span.onclick = function() { 
							span.textContent = obj[keys[i]];
							span.style = "color:white";
							span.onclick = null;
							span.outerHTML = '<pre>' + span.outerHTML + '</pre>';
							span.parentElement.onclick = function() {
								createElipsis();
								span.parentElement.remove();	
							};
						};
						buttonTitle.appendChild(span);
					})();
				} else if(typeof obj[keys[i]] == "function") {
					buttonTitle.innerHTML += `:<pre class="javascript"><span style="color:white">${obj[keys[i]]}</span></pre>`;
					buttonTitle.style.cursor = "pointer";
					buttonTitle.onclick = obj[keys[i]];
				} else if(typeof obj[keys[i]] == "undefined") buttonTitle.innerHTML += `<span style="color:white;opacity:0.5">: undefined</span>`;
				else buttonTitle.innerHTML += `<span style="color:white">: ${obj[keys[i]]}</span>`;

				(parent || scroller).appendChild(button);

			}

		};

		for(let i = 1; i < arguments.length; i++) {
			if(typeof arguments[i] == "object") createObjectButtons(arguments[i]);
			else scroller.insertAdjacentHTML("beforeEnd", `<div>${arguments[i]}</div>`);
		}

	} catch(err) { alert(err); }

}

(window.overrideConsole = function(w) {

	w.console.log = function() {
		print("default", ...arguments)
	};

	w.console.warn = function() {
		print("yellow", ...arguments);
	};

	w.onerror = function handleWindowError(msg, url, lnNum, colNo) {
		alert(arguments.join(", "));
		//print("red", "Error occured in " + url + ", " + msg + ", on " + lnNum + ":" + colNo);
	};

	w.console.error = function() {
		print("red", ...arguments);
	};

	w.console.clear = function() {
		console.element.getElementsByClassName("scroller console")[0].innerHTML = "";
	};

})(window);

function setActiveConsoleTab(t) {
	if(t == "dom" && !console.element.getElementsByClassName("scroller dom")[0].children.length) {
		for(let i = 0; i < documents.length; i++) {
			createDomObj(documents[i].head, console.element.getElementsByClassName("scroller dom")[0]);
			createDomObj(documents[i].body, console.element.getElementsByClassName("scroller dom")[0]);
		}
	}
	for(let tab of console.element.getElementsByClassName("scroller")) {
		if(tab.className.includes(t)) tab.style.display = "";
		else tab.style.display = "none";
	}
}

function clearConsole() {
	if(console.element.getElementsByClassName("scroller dom")[0].style.display) console.clear();
	else console.element.getElementsByClassName("scroller dom")[0].innerHTML = "";
}

function switchConsoleSide() {
	if(console.element.style.transform) console.element.style.transform = "";
	else console.element.style.transform = "translateX(-70vw)";
}

function beginElementSelect() {

	setTimeout(() => {

		const meev = function(e) {
			for(let h of document.getElementsByClassNameGlobal("es-hovered")) h.classList.remove("es-hovered");
			e.target.classList.add("es-hovered");
		};

		const mlev = function(e) {
			e.target.classList.remove("es-hovered");
		};

		const ev = function(e) {
			e.preventDefault();
			if(e.ctrlKey) return;
			console.element.getElementsByClassName("scroller dom")[0].innerHTML = "";
			for(let h of document.getElementsByClassNameGlobal("es-hovered")) h.classList.remove("es-hovered");
			for(let doc of documents) {
				doc.body.style.cursor = "";
				doc.removeEventListener("click", ev);
				doc.removeEventListener("mouseover", meev);
				doc.removeEventListener("mouseout", mlev);
			}
			console.log({ "$0" : e });
			window.$0 = e.target;
			const domObj = createDomObj(e.path[e.path.length - 4], console.element.getElementsByClassName("scroller dom")[0]);
			domObj.style.marginTop = "25px";
			try{
				for(let i = e.path.length - 4; i > 0; i--) Array.from(domObj.getElementsByTagName("span")).find(element => element.parentElement.referenceElement == e.path[i]).click();
				Array.from(document.getElementsByTagName("div")).find(element => element.referenceElement == e.target).click();
			} catch(err) { console.error(err); }
		};

		for(let doc of documents) {
			doc.body.style.cursor = "crosshair";
			doc.addEventListener("click", ev);
			doc.addEventListener("mouseover", meev);
			doc.addEventListener("mouseout", mlev);
		}

	}, 0);

}