return new class {

	get settingFields() {
		return {
			testVariable : { label : "Test variable", description : "I don't really know.", type : "bool" },
			string : { label : "A string", type : "string" },
			int : { label : "An integer", type : "int" },
			float : { label : "A floating point", type : "float" },
			custom : { type : "custom", element : function(plugin, set) {
				const element = document.createElement("div");
				element.textContent = plugin.settings.custom;
				element.onclick = () => set("the 'custom' setting will now be set to this string.");
				return element;
			}},
			customHTML : { type : "custom", html : `<div style="color:red">I cannot have a callback. Kms.</div>` },
			stringArray : { label : "Array of strings test", type : "string", array : true },
			list : { label : "But I have a purpose", type : "bool", list : true }
		};
	}

	get defaultSettings() {
		return {
			testVariable : false,
			string : "dad",
			int : 5,
			float : 6.9,
			custom : "I'm not set yet",
			customHTML : "I'm only for displaying things, like previews and shit",
			stringArray : [],
			list : {
				isGay : true,
				isStraight : false,
				isUseless : true
			}
		};
	}

	onSettingChanged(keyName, oldValue, newValue) {
		console.log(keyName, oldValue, newValue);
	}

	init() {
		const module = SpotifyInternals.getModuleById(9), unpatched = this.unpatchedDispatchEvent = module.dispatchEvent;
		module.dispatchEvent = function(e) {
			unpatched.apply(module, arguments);
			print("green", { dispatchEvent : e });
		};
		window.test = function() {
			try {
				const event = SpotifyInternals.getModuleById(10);
				console.log({ EventTypes : event.TYPES });
				SpotifyInternals.getModuleById(9).dispatchEvent(new event(event.TYPES.SHOW_NOTIFICATION_BUBBLE, { i18n : "dasdffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffsdfasdfasdfasdfasdfasdfasdfsadfasdfasdfasdfasdfadsfad" }));
				document.getElementById("profile-menu-toggle").click();
			} catch(err) { console.error(err); }
		};
	}

	end() {
		SpotifyInternals.getModuleById(9).dispatchEvent = this.unpatchedDispatchEvent;
	}

};